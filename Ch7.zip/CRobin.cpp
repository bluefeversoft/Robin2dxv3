//
//  CRobin.cpp
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 28/05/14.
//
//

#include "CRobin.h"
#include "CGameManager.h"
#include "Constants.h"

USING_NS_CC;

CRobin* CRobin::createWithFileName(char *fileName) {
	auto sprite = new CRobin;
	if(sprite && sprite->initWithFile(fileName)) {
		sprite->autorelease();
		return sprite;
	}
	CC_SAFE_DELETE(sprite);
	return nullptr;
}

void CRobin::Update(float dt){
	if(State == kRobinStateMoving) {
		// s = ut + 0.5 * a * t * t
		// v = u + a * t
		
		float distance = 0;
		float newSpeed = 0;
		
		distance = _speedY * dt + 0.5 * GRAVITY * dt * dt;
		newSpeed = _speedY + GRAVITY * dt;
		
		this->setPositionY(this->getPositionY() + distance);
		_speedY = newSpeed;
		
		if(this->getPositionY() > _topOfScreen) {
			this->setPositionY(_topOfScreen);
			_speedY = 0.0;
		}
		
	}
}

void CRobin::Reset(){
	State = kRobinStateStopped;
	SetStartSpeed();
	Size visibleSize = Director::getInstance()->getVisibleSize();
	this->setPosition(Vec2(visibleSize.width / 4 , visibleSize.height / 2));
}

void CRobin::SetStartSpeed(){
	_speedY = kRobinStartSpeedY;
}

void CRobin::SetParams(const float tos){
	_topOfScreen = tos;
}

cocos2d::Rect CRobin::TubeCollisionBox(){
	return this->getBoundingBox();
}




















