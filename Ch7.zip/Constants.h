//
//  Constants.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 27/05/14.
//
//

#ifndef SimpleFlappyRobin_Constants_h
#define SimpleFlappyRobin_Constants_h

#define kZindexBG 0
#define kZindexFloor 40
#define kZindexRobin 100

#define kRobinStateMoving 0
#define kRobinStateStopped 1
#define kRobinStartSpeedY 300 * GETSCALEY * GETSCALEFAC

#define GRAVITY -620 * GETSCALEY * GETSCALEFAC

#endif
