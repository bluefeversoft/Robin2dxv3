#include "HelloWorldScene.h"
#include "Constants.h"
#include "CGameManager.h"
#include "CRobin.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();
	
    // add layer as a child to scene
    scene->addChild(layer);
	
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
		{
        return false;
		}
	
	char FileName[32];
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
	
	CGameManager::Instance()->SetUpScaleFactors();
	
	CCLOG("visibleSize:%.1f,%.1f",visibleSize.width,visibleSize.height);
	CCLOG("origin:%.1f,%.1f",origin.x,origin.y);
	
	GETFILENAME(FileName, 32, "BG", ".png");
	auto bgSprite = Sprite::create(FileName);
	SCALENODE_XY(bgSprite);
	bgSprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	bgSprite->setAnchorPoint(Vec2(0.5, 0.5));
	this->addChild(bgSprite, kZindexBG);
	
	GETFILENAME(FileName, 32, "Floor", ".png");
	auto floorSprite = Sprite::create(FileName);
	SCALENODE_XY(floorSprite);
	floorSprite->setPosition(Vec2(visibleSize.width / 2, 0.0));
	floorSprite->setAnchorPoint(Vec2(0.5, 0.0));
	this->addChild(floorSprite, kZindexFloor);
	_floorBottom = floorSprite->getBoundingBox().size.height / 2;
	
	GETFILENAME(FileName, 32, "Robin", ".png");
	_robin = CRobin::createWithFileName(FileName);
	SCALENODE_Y(_robin);
	this->addChild(_robin, kZindexRobin);
	_robin->Reset();
	_robin->SetParams(visibleSize.height);
	
	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
	
	_gameOver = true;
	
	schedule(schedule_selector(HelloWorld::gameUpdate));
	
    return true;
}

void HelloWorld::gameUpdate(float dt) {
	// CCLOG("HelloWorld::gameUpdate dt:%f",dt);
	if(_gameOver == false) {
		if(_robin->getPositionY() < _floorBottom) {
			_gameOver = true;
			_robin->Reset();
		} else {
			_robin->Update(dt);
		}
	}
}

bool HelloWorld::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event) {
   //	CCLOG("HelloWorld::onTouchBegan x:%f y:%f", touch->getLocation().x, touch->getLocation().y);
	
	if(_gameOver == true) {
		_robin->State = kRobinStateMoving;
		_gameOver = false;
	} else {
		_robin->SetStartSpeed();
	}
	
	return true;
}




























