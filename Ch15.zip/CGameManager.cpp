//
//  CGameManager.cpp
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 27/05/14.
//
//

#include "CGameManager.h"
#include "cocos2d.h"
#include "Constants.h"
#include "HelloWorldScene.h"
#include "SettingsScene.h"

USING_NS_CC;

#define kEXTHD "-HD"
#define kEXTUHD "-UHD"
#define kEXTND "-ND"

#define kNumExplosions 2
#define kNumRobinTap 1
#define kNumSuccess 2

CGameManager *CGameManager::_pInstance = NULL;

void CGameManager::RunScene(const int sceneNum) {
	Scene *pScene = NULL;
	
	if(sceneNum == kSceneGame) {
		pScene = HelloWorld::createScene();
	} else if(sceneNum == kSceneSettings) {
		pScene = SettingsScene::createScene();
	}
	
	if(pScene != NULL) {
		if(Director::getInstance()->getRunningScene() == NULL) {
			Director::getInstance()->runWithScene(pScene);
		} else {
			Director::getInstance()->replaceScene(pScene);
		}
	}
}

CGameManager *CGameManager::Instance() {
	if(!_pInstance) {
		_pInstance = new CGameManager;
	}
	return _pInstance;
}

float CGameManager::GetScaleX() {
	return _scaleX;
}

float CGameManager::GetScaleY() {
	return _scaleY;
}

float CGameManager::GetScaleFactor() {
	return _scalFactor;
}


void CGameManager::SetUpScaleFactors() {
	Size visibleSize = Director::getInstance()->getVisibleSize();
	
	_extension = (char*)kEXTHD;
	_scalFactor = 1.0;
	
	if(visibleSize.width * visibleSize.height > 960 * 640) {
		_scalFactor = 2.0;
		_extension = (char*)kEXTUHD;
	} else if(visibleSize.width * visibleSize.height <= 480 * 320) {
		_scalFactor = 0.5;
		_extension = (char*)kEXTND;
	}
	
	_scaleX = visibleSize.width / (960 * _scalFactor);
	_scaleY = visibleSize.height / (640 * _scalFactor);
	
	CCLOG("_scalFactor:%.2f _scaleX:%.2f _scaleY:%.2f",
		 _scalFactor,_scaleX,_scaleY );
}

void CGameManager::GetFileName(char *array, const int len, const char *name, const char *fileExt) {
	memset(array, 0, sizeof(char) * len);
	sprintf(array, "%s%s%s", name, _extension, fileExt);
}

void CGameManager::LateInit() {
	int index = 0;
	for(index = 0; index < kNumExplosions; ++index) {
		PreLoadEffect("Explosion", index+1);
	}
	
	for(index = 0; index < kNumRobinTap; ++index) {
		PreLoadEffect("RobinTap", index+1);
	}
	
	for(index = 0; index < kNumSuccess; ++index) {
		PreLoadEffect("Success", index+1);
	}
}

void CGameManager::PlayEffect(const int effectNum) {
	switch (effectNum) {
		case kEffectExplosion:
			PlayEffectName("Explosion", kNumExplosions);
			break;
		case kEffectRobinTap:
			PlayEffectName("RobinTap", kNumRobinTap);
			break;
		case kEffectSuccess:
			PlayEffectName("Success", kNumSuccess);
			break;
			
		default:
			break;
	}
}

void CGameManager::PreLoadEffect(const char* name, const int num) {
	char EffectName[32];
	memset(EffectName, 0, sizeof(EffectName));
	sprintf(EffectName, "%s%d.wav",name,num);
	CocosDenshion::SimpleAudioEngine::getInstance()->preloadEffect(EffectName);
}

void CGameManager::PlayEffectName(const char* name, const int num) {
	int randnum = rand() % num + 1;
	
	char EffectName[32];
	memset(EffectName, 0, sizeof(EffectName));
	sprintf(EffectName, "%s%d.wav",name,randnum);
	CocosDenshion::SimpleAudioEngine::getInstance()->playEffect(EffectName);
}

































