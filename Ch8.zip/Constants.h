//
//  Constants.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 27/05/14.
//
//

#ifndef SimpleFlappyRobin_Constants_h
#define SimpleFlappyRobin_Constants_h

#define kZindexBG 0
#define kZindexFloor 40
#define kZindexRobin 100
#define kZindexCloudFast 20
#define kZindexCloudSlow 10
#define kZindexTree 50
#define kZindexMount 30

#define kCloudScaleSlow 0.4 * GETSCALEY
#define kCloudScaleFast 0.85 * GETSCALEY
#define kMountScale 0.8 * GETSCALEY
#define kTreeScale 1.0 * GETSCALEY

#define kCloudSpeedSlow 13.0 * GETSCALEY * GETSCALEFAC
#define kCloudSpeedFast 53.0 * GETSCALEY * GETSCALEFAC
#define kMountSpeed 30.0 * GETSCALEY * GETSCALEFAC
#define kTreeSpeed  70.0 * GETSCALEY * GETSCALEFAC

#define kRobinStateMoving 0
#define kRobinStateStopped 1
#define kRobinStartSpeedY 300 * GETSCALEY * GETSCALEFAC

#define GRAVITY -620 * GETSCALEY * GETSCALEFAC




#endif
