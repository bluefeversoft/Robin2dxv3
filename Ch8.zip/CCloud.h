//
//  CCloud.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 05/06/14.
//
//

#ifndef __SimpleFlappyRobin__CCloud__
#define __SimpleFlappyRobin__CCloud__

#include "cocos2d.h"

class CCloud : public cocos2d::Sprite {
	
public:
	int State;
	
	static CCloud* createWithFileName(char *fileName);
	
	void Start();
	void Stop();
	void SetSpeedAndWidth(const float speed, const float width);
	
	CCloud() {};
	
private:
	
	void ReachedDestination();
	
	float _speed;
	float _screenWidth;
	float _xOffSet;
};

#endif /* defined(__SimpleFlappyRobin__CCloud__) */
