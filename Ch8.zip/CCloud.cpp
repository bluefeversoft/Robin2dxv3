//
//  CCloud.cpp
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 05/06/14.
//
//

#include "CCloud.h"

USING_NS_CC;

CCloud* CCloud::createWithFileName(char *fileName) {
	auto sprite = new CCloud;
	if(sprite && sprite->initWithFile(fileName)) {
		sprite->autorelease();
		return sprite;
	}
	CC_SAFE_DELETE(sprite);
	return nullptr;
}

void CCloud::Start() {
	this->stopAllActions();
	float currentX = this->getPositionX();
	float distance = currentX + _xOffSet;
	float time = distance / _speed;
	Vec2 destination = Vec2(-_xOffSet, this->getPositionY());
	
	MoveTo *actionMove = MoveTo::create(time, destination);
	CallFunc *actionMoveDone = CallFunc::create(CC_CALLBACK_0(CCloud::ReachedDestination, this));
	this->runAction(Sequence::create(actionMove, actionMoveDone, NULL));
}

void CCloud::Stop() {
	this->stopAllActions();
}

void CCloud::SetSpeedAndWidth(const float speed, const float width) {
	_speed = speed;
	_screenWidth = width;
	_xOffSet = this->getBoundingBox().size.width;
}

void CCloud::ReachedDestination() {
	this->setPositionX(_xOffSet + _screenWidth);
	this->Start();
}













