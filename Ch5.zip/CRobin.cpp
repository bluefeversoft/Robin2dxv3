//
//  CRobin.cpp
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 28/05/14.
//
//

#include "CRobin.h"

CRobin* CRobin::createWithFileName(char *fileName) {
	auto sprite = new CRobin;
	if(sprite && sprite->initWithFile(fileName)) {
		sprite->autorelease();
		return sprite;
	}
	CC_SAFE_DELETE(sprite);
	return nullptr;
}

void CRobin::Update(float dt){
	
}

void CRobin::Reset(){
	
}

void CRobin::SetStartSpeed(){
	
}

void CRobin::SetParams(const float tos){
	
}

cocos2d::Rect CRobin::TubeCollisionBox(){
	return this->getBoundingBox();
}


