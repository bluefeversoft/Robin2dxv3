//
//  CRobin.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 28/05/14.
//
//

#ifndef __SimpleFlappyRobin__CRobin__
#define __SimpleFlappyRobin__CRobin__

#include "cocos2d.h"

class CRobin : public cocos2d::Sprite {
	
public:
	int State;
	
	static CRobin* createWithFileName(char *fileName);
	void Update(float dt);
	void Reset();
	void SetStartSpeed();
	void SetParams(const float tos);
	cocos2d::Rect TubeCollisionBox();
	
	CRobin() {};
	
private:
	float _speedY;
	float _topOfScreen;
	
};

#endif /* defined(__SimpleFlappyRobin__CRobin__) */
