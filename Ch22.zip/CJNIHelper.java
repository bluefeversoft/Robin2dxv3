package org.cocos2dx.cpp;

import android.content.SharedPreferences;
import android.util.Log;

public class CJNIHelper {
	
	final static String TAG = "Cocos2dx CJNIHelper Java Layer";
	
	public final static String SETTINGS_NAME = "RobinSettings";
	
	public final static String HIGHSCORE_KEY = "HIGHSCORE_KEY";
	
	static SharedPreferences prefs;
	
	public static void SetUp(SharedPreferences sharedPrefs) {
		prefs = sharedPrefs;
		Log.d(TAG, "SetUp Preferences Called");
	}

}
