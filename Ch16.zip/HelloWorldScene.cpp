#include "HelloWorldScene.h"
#include "Constants.h"
#include "CGameManager.h"
#include "CRobin.h"


USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();
	
    // add layer as a child to scene
    scene->addChild(layer);
	
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
		{
        return false;
		}
	
	char FileName[32];
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
	
	// CGameManager::Instance()->SetUpScaleFactors();
	
	CCLOG("visibleSize:%.1f,%.1f",visibleSize.width,visibleSize.height);
	CCLOG("origin:%.1f,%.1f",origin.x,origin.y);
	
	const float LabelFontSize = 48 * GETSCALEY * GETSCALEFAC;
	const float ScorePositionX = 24 * GETSCALEY * GETSCALEFAC;
	const float ScorePositionY = 24 * GETSCALEY * GETSCALEFAC;
	const float SettingsGap = 24 * GETSCALEY * GETSCALEFAC;
	
	GETFILENAME(FileName, 32, "BG", ".png");
	auto bgSprite = Sprite::create(FileName);
	SCALENODE_XY(bgSprite);
	bgSprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	bgSprite->setAnchorPoint(Vec2(0.5, 0.5));
	this->addChild(bgSprite, kZindexBG);
	
	GETFILENAME(FileName, 32, "Floor", ".png");
	auto floorSprite = Sprite::create(FileName);
	SCALENODE_XY(floorSprite);
	floorSprite->setPosition(Vec2(visibleSize.width / 2, 0.0));
	floorSprite->setAnchorPoint(Vec2(0.5, 0.0));
	this->addChild(floorSprite, kZindexFloor);
	_floorBottom = floorSprite->getBoundingBox().size.height / 2;
	
	GETFILENAME(FileName, 32, "Robin", ".png");
	_robin = CRobin::createWithFileName(FileName);
	SCALENODE_Y(_robin);
	this->addChild(_robin, kZindexRobin);
	_robin->Reset();
	_robin->SetParams(visibleSize.height);
	_robin->setPosition(Vec2(visibleSize.width / 4 , visibleSize.height / 2));
	
	_scoreLabel = AddLabel(LabelFontSize, "Score 0", Vec2(0.0, 1.0),
						   Vec2(ScorePositionX, visibleSize.height - ScorePositionY));
	_highScoreLabel = AddLabel(LabelFontSize, "Best 0", Vec2(0.0 , 1.0),
							   Vec2(ScorePositionX,
									visibleSize.height - ScorePositionY -
									_scoreLabel->getBoundingBox().size.height));
	_gameOverLabel = AddLabel(LabelFontSize, "Game Over", Vec2(0.5 , 0.5),
							  Vec2(visibleSize.width / 2, visibleSize.height / 2));
	_startLabel = AddLabel(LabelFontSize, "Tap The Screen To Start", Vec2(0.5 , 0.5),
							 Vec2(visibleSize.width / 2, visibleSize.height * 3 / 4));
	_settingsLabel = AddLabel(LabelFontSize, "SETTINGS", Vec2(1.0 , 1.0),
							  Vec2(visibleSize.width - SettingsGap, visibleSize.height  - SettingsGap));
	_exitLabel = AddLabel(LabelFontSize, "EXIT", Vec2(1.0 , 0.0),
						  Vec2(visibleSize.width - SettingsGap, SettingsGap));
	
	_gameOverLabel->setVisible(false);
	
	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
	
	_gameOver = true;
	_acceptTouches = true;
	_gameTime = 0;
	_middleY = visibleSize.height / 2;
	_lastSpawnTime = 0;
	_nextSpawnTime = 0.2;
	_tubes = Vector<CTube*>{30};
	CreateClouds();
	
	schedule(schedule_selector(HelloWorld::gameUpdate));
	
    return true;
}

void HelloWorld::gameUpdate(float dt) {
	// CCLOG("HelloWorld::gameUpdate dt:%f",dt);
	if(_gameOver == false) {
		_gameTime += dt;
		_lastSpawnTime += dt;
		if(_lastSpawnTime > _nextSpawnTime) {
			SetSpawnTime();
			SpawnNewTubes();
		}
		if(_robin->getPositionY() < _floorBottom) {
			_gameOver = true;
		} else {
			for(auto tube: this->_tubes) {
				if(_robin->TubeCollisionBox().intersectsRect(tube->boundingBox())) {
					_gameOver = true;
					break;
				}
			}
		}
		
		if(_gameOver == false) {
			_robin->Update(dt);
		} else {
			GameOver();
		}
	}
}

bool HelloWorld::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event) {
	//	CCLOG("HelloWorld::onTouchBegan x:%f y:%f", touch->getLocation().x, touch->getLocation().y);
	if(!_acceptTouches) return false;
	
	CGameManager::Instance()->PlayEffect(kEffectRobinTap);
	
	Point tp = Point(touch->getLocation().x,touch->getLocation().y);
	
	if(_settingsLabel->getBoundingBox().containsPoint(tp)) {
		CGameManager::Instance()->RunScene(kSceneSettings);
	}

	if(_gameOver == true) {
		StartGame();
	} else {
		_robin->SetStartSpeed();
	}
	
	return true;
}

void HelloWorld::AddCloud(const float speed, const cocos2d::Vec2 position, const float scale, const int zIndex, char *fileName) {
	Size visibleSize = Director::getInstance()->getVisibleSize();
	CCloud *cloud = CCloud::createWithFileName(fileName);
	cloud->SetSpeedAndWidth(speed, visibleSize.width);
	cloud->cocos2d::Node::setPosition(position);
	cloud->setScale(scale);
	this->addChild(cloud, zIndex);
	_clouds.pushBack(cloud);
}

void HelloWorld::StartClouds() {
	
	for(auto cloud: this->_clouds) {
		cloud->Start();
	}
	
	for(auto tube: this->_tubes) {
		tube->Stop();
	}
}

void HelloWorld::StopClouds() {
	for(auto cloud: this->_clouds) {
		cloud->Stop();
	}
	
	for(auto tube: this->_tubes) {
		tube->stopAllActions();
	}
}

void HelloWorld::CreateClouds() {
	_clouds = Vector<CCloud*>{30};
	char FileName[32];
	GETFILENAME(FileName, 32, "Cloud", ".png");
	AddCloud(kCloudSpeedSlow, SCALEPOS(700, 610), kCloudScaleSlow, kZindexCloudSlow, FileName);
	AddCloud(kCloudSpeedSlow, SCALEPOS(150,570), kCloudScaleSlow, kZindexCloudSlow, FileName);
	
	AddCloud(kCloudSpeedFast, SCALEPOS(150,300), kCloudScaleFast, kZindexCloudFast, FileName);
	AddCloud(kCloudSpeedFast, SCALEPOS(400,500), kCloudScaleFast, kZindexCloudFast, FileName);
	AddCloud(kCloudSpeedFast, SCALEPOS(880,400), kCloudScaleFast, kZindexCloudFast, FileName);
	
	GETFILENAME(FileName, 32, "Mount", ".png");
	AddCloud(kMountSpeed, SCALEPOS(300,170), kMountScale, kZindexMount, FileName);
	AddCloud(kMountSpeed, SCALEPOS(800,170), kMountScale, kZindexMount, FileName);
	
	GETFILENAME(FileName, 32, "Tree", ".png");
	AddCloud(kTreeSpeed, SCALEPOS(128,72), kTreeScale, kZindexTree, FileName);
	AddCloud(kTreeSpeed, SCALEPOS(624,72), kTreeScale, kZindexTree, FileName);
	AddCloud(kTreeSpeed, SCALEPOS(864,72), kTreeScale, kZindexTree, FileName);
}

void HelloWorld::SetSpawnTime() {
	_lastSpawnTime = 0;
	_nextSpawnTime = (float)(rand() % kTubeSpawnTimeVariance) / 10 + kTubeSpawnMinTime;
}

void HelloWorld::SpawnNewTubes() {
	
	int ourChance = rand() % 3 + 1;
	
	while(1) {
		if(_lastTubeType == kTubeTypeUpper && ourChance == 1) {
			ourChance = rand() % 3 + 1;
		} else if(_lastTubeType == kTubeTypeLower && ourChance == 2) {
			ourChance = rand() % 3 + 1;
		} else if(_lastTubeType == kTubeTypePair && ourChance == 3) {
			ourChance = rand() % 3 + 1;
		} else {
			break;
		}
	}
	
	if(ourChance == 1) {
		SpawnUpperOrLower(true);
	} else if(ourChance == 2) {
		SpawnUpperOrLower(false);
	} else {
		SpawnTubePair();
	}
}


void HelloWorld::SpawnUpperOrLower(bool isUpper) {
	_lastTubeType = isUpper == true ? kTubeTypeUpper : kTubeTypeLower;
	
	int YMax = isUpper == true ? _middleY : kSingleGapTop;
	int YMin = isUpper == true ? kSingleGapBottom : _middleY;
	
	if(isUpper == false) {
		if(YMax - _lastGetUnderY > kTubeMaxUpPixels) {
			YMax = _lastGetUnderY + kTubeMaxUpPixels;
		}
	}
	
	int YRange = abs(YMax - YMin);
	int Ypos = YMax - rand() % YRange;
	
	if(isUpper) {
		_lastGetUnderY = Ypos;
	} else {
		_lastGetUnderY = _middleY;
	}
	SpawnATube(isUpper, Ypos);
}


void HelloWorld::SpawnTubePair() {
	_lastTubeType = kTubeTypePair;
	
	int Gap = kDoubleGapMin + (rand() % (int)(kDoubleGapMax - kDoubleGapMin));
	int YRange = kDoubleGapTop - Gap - kDoubleGapBottom;
	int TopY = kDoubleGapTop - (rand() % YRange);
	int BottomY = TopY - Gap;
	
	_lastGetUnderY = TopY;
	
	SpawnATube(true, TopY);
	SpawnATube(false, BottomY);
}


void HelloWorld::SpawnATube(bool isUpper, float Ypos) {
	CTube *tube = getNextTube();
	
	if(isUpper) {
		tube->setAnchorPoint(Vec2(0.5,0));
		tube->setFlippedY(false);
	} else {
		tube->setAnchorPoint(Vec2(0.5,1));
		tube->setFlippedY(true);
	}
	
	tube->setPositionY(Ypos);
	tube->Start();
}


CTube *HelloWorld::getNextTube() {
	for(auto tube: _tubes) {
		if(tube->State == kTubeStateInActive) {
			return tube;
		}
	}
	char FileName[32];
	GETFILENAME(FileName, 32, "Tube", ".png");
	Size visibleSize = Director::getInstance()->getVisibleSize();
	CTube *newTube = CTube::createWithFileName(FileName);
	SCALENODE_Y(newTube);
	newTube->Initialise(kTreeSpeed, visibleSize.width);
	this->addChild(newTube, kZindexTube);
	_tubes.pushBack(newTube);
	return newTube;
}

void HelloWorld::StartGame() {
	_startLabel->setVisible(false);
	_robin->State = kRobinStateMoving;
	_gameOver = false;
	StartClouds();
}

void HelloWorld::StopGame() {
	_nextSpawnTime = 0.2;
	StopClouds();
}

void HelloWorld::GameOver() {
	CGameManager::Instance()->PlayEffect(kEffectExplosion);
	_gameOverLabel->setVisible(true);
	_acceptTouches = false;
	_robin->Reset();
	StopGame();
	scheduleOnce(schedule_selector(HelloWorld::ReEnableAfterGameOver), 2.5f);
}

void HelloWorld::ReEnableAfterGameOver(float dt) {
	_gameOverLabel->setVisible(false);
	_startLabel->setVisible(true);
	_acceptTouches = true;
	_robin->setPositionY(_middleY);
}

Label* HelloWorld::AddLabel(const float fontSize, const char *text,
							const cocos2d::Vec2 anchor, const cocos2d::Vec2 position) {
	Label *theLabel = Label::createWithTTF(text, kFontName, fontSize);
	theLabel->setAnchorPoint(anchor);
	theLabel->setPosition(position);
	theLabel->setColor(Color3B::RED);
	this->addChild(theLabel, kZindexRobin);
	return theLabel;
}
































