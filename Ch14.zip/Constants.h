//
//  Constants.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 27/05/14.
//
//

#ifndef SimpleFlappyRobin_Constants_h
#define SimpleFlappyRobin_Constants_h

#define kZindexBG 0
#define kZindexFloor 40
#define kZindexTube 35
#define kZindexRobin 100
#define kZindexCloudFast 20
#define kZindexCloudSlow 10
#define kZindexTree 50
#define kZindexMount 30

#define kCloudScaleSlow 0.4 * GETSCALEY
#define kCloudScaleFast 0.85 * GETSCALEY
#define kMountScale 0.8 * GETSCALEY
#define kTreeScale 1.0 * GETSCALEY

#define kCloudSpeedSlow 13.0 * GETSCALEY * GETSCALEFAC
#define kCloudSpeedFast 53.0 * GETSCALEY * GETSCALEFAC
#define kMountSpeed 30.0 * GETSCALEY * GETSCALEFAC
#define kTreeSpeed  70.0 * GETSCALEY * GETSCALEFAC

#define kRobinStateMoving 0
#define kRobinStateStopped 1
#define kRobinStartSpeedY 300 * GETSCALEY * GETSCALEFAC

#define GRAVITY -620 * GETSCALEY * GETSCALEFAC

#define kTubeStateActive 0
#define kTubeStateInActive 1
#define kTubeInActiveX -1000 * GETSCALEX * GETSCALEFAC

#define kTubeSpawnMinTime 2.3
#define kTubeSpawnTimeVariance 8

#define kTubeTypeUpper 0
#define kTubeTypeLower 1
#define kTubeTypePair 2
#define kTubeTypeNone 3

#define kSingleGapTop 440 * GETSCALEY * GETSCALEFAC
#define kSingleGapBottom 230 * GETSCALEY * GETSCALEFAC
#define kSingleGapMax 280 * GETSCALEY * GETSCALEFAC
#define kSingleGapMin 160 * GETSCALEY * GETSCALEFAC

#define kDoubleGapTop 480 * GETSCALEY * GETSCALEFAC
#define kDoubleGapBottom 120 * GETSCALEY * GETSCALEFAC
#define kDoubleGapMax 220 * GETSCALEY * GETSCALEFAC
#define kDoubleGapMin 140 * GETSCALEY * GETSCALEFAC

#define kTubeMaxUpPixels 180 * GETSCALEY * GETSCALEFAC

#define kFontName "Marker Felt.ttf"

#define kEffectRobinTap 0
#define kEffectSuccess 1
#define kEffectExplosion 2

#endif
































