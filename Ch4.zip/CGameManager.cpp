//
//  CGameManager.cpp
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 27/05/14.
//
//

#include "CGameManager.h"
#include "cocos2d.h"

USING_NS_CC;

#define kEXTHD "-HD"
#define kEXTUHD "-UHD"
#define kEXTND "-ND"

CGameManager *CGameManager::_pInstance = NULL;

CGameManager *CGameManager::Instance() {
	if(!_pInstance) {
		_pInstance = new CGameManager;
	}
	return _pInstance;
}

float CGameManager::GetScaleX() {
	return _scaleX;
}

float CGameManager::GetScaleY() {
	return _scaleY;
}

float CGameManager::GetScaleFactor() {
	return _scalFactor;
}

void CGameManager::SetUpScaleFactors() {
	Size visibleSize = Director::getInstance()->getVisibleSize();
	
	_extension = (char*)kEXTHD;
	_scalFactor = 1.0;
	
	if(visibleSize.width * visibleSize.height > 960 * 640) {
		_scalFactor = 2.0;
		_extension = (char*)kEXTUHD;
	} else if(visibleSize.width * visibleSize.height <= 480 * 320) {
		_scalFactor = 0.5;
		_extension = (char*)kEXTND;
	}
	
	_scaleX = visibleSize.width / (960 * _scalFactor);
	_scaleY = visibleSize.height / (640 * _scalFactor);
	
	CCLOG("_scalFactor:%.2f _scaleX:%.2f _scaleY:%.2f",
		 _scalFactor,_scaleX,_scaleY );
}

void CGameManager::GetFileName(char *array, const int len, const char *name, const char *fileExt) {
	memset(array, 0, sizeof(char) * len);
	sprintf(array, "%s%s%s", name, _extension, fileExt);
}


























