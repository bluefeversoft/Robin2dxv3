//
//  SettingsScene.cpp
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 16/06/14.
//
//

#include "SettingsScene.h"
#include "Constants.h"
#include "CGameManager.h"

USING_NS_CC;

Scene* SettingsScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = SettingsScene::create();
	
    // add layer as a child to scene
    scene->addChild(layer);
	
    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool SettingsScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
		{
        return false;
		}
	
	char FileName[32];
    
    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
	
	GETFILENAME(FileName, 32, "BG", ".png");
	auto bgSprite = Sprite::create(FileName);
	SCALENODE_XY(bgSprite);
	bgSprite->setPosition(Vec2(visibleSize.width / 2, visibleSize.height / 2));
	bgSprite->setAnchorPoint(Vec2(0.5, 0.5));
	this->addChild(bgSprite, kZindexBG);
	
	
	const float BackButtonBottom = 40 * GETSCALEY * GETSCALEFAC;
	const float BackButtonLeft = 80 * GETSCALEX * GETSCALEFAC;
	const float FontSize = 40 * GETSCALEY * GETSCALEFAC;
	const float GapToAdjust = 140 * GETSCALEY * GETSCALEFAC;
	const float LeftGap = 120 * GETSCALEY * GETSCALEFAC;
	
	
	AddLabelVoid(FontSize, "SETTINGS", Vec2(0.5,1.0), Vec2(visibleSize.width / 2, visibleSize.height - BackButtonBottom));
	AddLabelVoid(FontSize, "EFFETCS VOL.", Vec2(0.0,0.5), Vec2(LeftGap, visibleSize.height/2 + BackButtonBottom));
	
	_backLabel = AddLabel(FontSize, "BACK", Vec2(0.0,0.0), Vec2(BackButtonLeft, BackButtonBottom));
	
	_effVolPlusLabel = AddLabel(FontSize, "+", Vec2(1.0,0.5), Vec2(visibleSize.width - LeftGap, visibleSize.height / 2 + BackButtonBottom));
	_effValueLabel = AddLabel(FontSize, "0", Vec2(0.5,0.5), Vec2(_effVolPlusLabel->getBoundingBox().origin.x - GapToAdjust, visibleSize.height / 2 + BackButtonBottom));
	_effVolMinusLabel = AddLabel(FontSize, "-", Vec2(0.5,0.5), Vec2(_effValueLabel->getBoundingBox().origin.x - GapToAdjust, visibleSize.height / 2 + BackButtonBottom));
	
	float EffectBottomY = _effValueLabel->getBoundingBox().origin.y;
	
	AddLabelVoid(FontSize, "MUSIC VOL.", Vec2(0.0,1.0), Vec2(LeftGap, EffectBottomY - BackButtonBottom * 2));
	_musVolplusLabel = AddLabel(FontSize, "+", Vec2(0.5,1.0), Vec2(visibleSize.width - LeftGap, EffectBottomY - BackButtonBottom * 2));
	_musicValueLabel = AddLabel(FontSize, "0", Vec2(0.5,1.0), Vec2(_effVolPlusLabel->getBoundingBox().origin.x - GapToAdjust, EffectBottomY - BackButtonBottom * 2));
	_musVolMinusLabel = AddLabel(FontSize, "-", Vec2(0.5,1.0), Vec2(_effValueLabel->getBoundingBox().origin.x - GapToAdjust, EffectBottomY - BackButtonBottom * 2));
	
	SetLabelValues();
	
	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(SettingsScene::onTouchBegan, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);
	
    return true;
}

bool SettingsScene::onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event) {
	//	CCLOG("HelloWorld::onTouchBegan x:%f y:%f", touch->getLocation().x, touch->getLocation().y);
	
	CGameManager::Instance()->PlayEffect(kEffectRobinTap);
	Point tp = Point(touch->getLocation().x,touch->getLocation().y);
	
	if(_backLabel->getBoundingBox().containsPoint(tp)) {
		CGameManager::Instance()->RunScene(kSceneGame);
	}
	
	return true;
}

Label* SettingsScene::AddLabel(const float fontSize, const char *text,
							const cocos2d::Vec2 anchor, const cocos2d::Vec2 position) {
	Label *theLabel = Label::createWithTTF(text, kFontName, fontSize);
	theLabel->setAnchorPoint(anchor);
	theLabel->setPosition(position);
	theLabel->setColor(Color3B::RED);
	this->addChild(theLabel, kZindexRobin);
	return theLabel;
}

void SettingsScene::AddLabelVoid(const float fontSize, const char *text,
							   const cocos2d::Vec2 anchor, const cocos2d::Vec2 position) {
	Label *theLabel = Label::createWithTTF(text, kFontName, fontSize);
	theLabel->setAnchorPoint(anchor);
	theLabel->setPosition(position);
	theLabel->setColor(Color3B::RED);
	this->addChild(theLabel, kZindexRobin);
}

void SettingsScene::SetLabelValues() {
	char ValueString[16];
	sprintf(ValueString, "%d", CGameManager::Instance()->GetVol(kVolTypeMusic));
	_musicValueLabel->setString(ValueString);
	
	memset(ValueString, 0, sizeof(ValueString));
	sprintf(ValueString, "%d", CGameManager::Instance()->GetVol(kVolTypeEffect));
	_effValueLabel->setString(ValueString);
}




















