//
//  CGameManager.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 27/05/14.
//
//

#ifndef __SimpleFlappyRobin__CGameManager__
#define __SimpleFlappyRobin__CGameManager__

#include <iostream>

class CGameManager {
	
public:
	
	static CGameManager* Instance();
	
	float GetScaleX();
	float GetScaleY();
	float GetScaleFactor();
	
	void SetUpScaleFactors();
	
	void GetFileName(char *array, const int len, const char *name, const char *fileExt);
	
	void LateInit();
	void PlayEffect(const int effectNum);
	
	void RunScene(const int sceneNum);
	
	int GetVol(const int volType);
	void SetVol(const int volType, const int val);

private:
	
	CGameManager() {};
	CGameManager(CGameManager const&){};
	CGameManager& operator=(CGameManager const&){};
	
	void PreLoadEffect(const char* name, const int num);
	void PlayEffectName(const char* name, const int num);
	
	static CGameManager* _pInstance;
	
	float _scaleX;
	float _scaleY;
	float _scalFactor;
	char *_extension;
	
	int _musicVol;
	int _effectsVol;
	
};

#define GETSCALEX ( CGameManager::Instance()->GetScaleX() )
#define GETSCALEY ( CGameManager::Instance()->GetScaleY() )
#define GETSCALEFAC ( CGameManager::Instance()->GetScaleFactor() )

#define SCALEX(p) ( (p) * GETSCALEX)
#define SCALEY(p) ( (p) * GETSCALEY)

#define SCALEPOS(x,y) ( Vec2 (  GETSCALEX * (x) * GETSCALEFAC, GETSCALEY * (y) * GETSCALEFAC) )

#define SCALEFONT(p) ( (p) * SCALEY * GETSCALEFAC )

#define GETFILENAME(a,l,n,e) \
	(CGameManager::Instance()->GetFileName(a,l,n,e))

#define SCALENODE_XY(n) \
	n->setScaleX(GETSCALEX); \
	n->setScaleY(GETSCALEY)

#define SCALENODE_Y(n) \
n->setScale(GETSCALEY)






















#endif /* defined(__SimpleFlappyRobin__CGameManager__) */
