//
//  CTube.h
//  SimpleFlappyRobin
//
//  Created by ScreenCast on 09/06/14.
//
//

#ifndef __SimpleFlappyRobin__CTube__
#define __SimpleFlappyRobin__CTube__

#include "cocos2d.h"

class CTube : public cocos2d::Sprite {
	
public:
	int State;
	bool Scored;
	
	static CTube* createWithFileName(char *fileName);
	
	void Start();
	void Stop();
	void Initialise(const float speed, const float width);
	
	CTube() {};
	
private:
	
	void ReachedDestination();
	
	float _speed;
	float _screenWidth;
	float _xOffSet;
};

#endif /* defined(__SimpleFlappyRobin__CTube__) */
