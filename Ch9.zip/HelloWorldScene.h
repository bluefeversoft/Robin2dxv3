#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "CCloud.h"
#include "CTube.h"

class CRobin;


class HelloWorld : public cocos2d::Layer
{
private:
	CRobin *_robin;
	
	void gameUpdate(float dt);

	bool _gameOver;
	float _floorBottom;
	
	cocos2d::Vector<CCloud*> _clouds;
	cocos2d::Vector<CTube*> _tubes;
	
	float _nextSpawnTime;
	float _lastSpawnTime;
	float _lastGetUnderY;
	float _gameTime;
	
	void AddCloud(const float speed, const cocos2d::Vec2 position, const float scale, const int zIndex, char *fileName);
	void StartClouds();
	void StopClouds();
	void CreateClouds();
	
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();
	
    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();
    
    // implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);
	
	bool onTouchBegan(cocos2d::Touch *touch, cocos2d::Event *event);
	
};

#endif // __HELLOWORLD_SCENE_H__